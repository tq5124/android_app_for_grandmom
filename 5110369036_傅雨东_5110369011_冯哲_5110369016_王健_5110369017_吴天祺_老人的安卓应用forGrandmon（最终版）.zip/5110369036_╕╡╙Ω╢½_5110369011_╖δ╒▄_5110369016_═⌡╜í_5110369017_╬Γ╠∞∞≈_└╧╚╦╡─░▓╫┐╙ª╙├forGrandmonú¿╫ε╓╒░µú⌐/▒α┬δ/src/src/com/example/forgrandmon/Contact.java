package com.example.forgrandmon;

import android.graphics.Bitmap;

/**
 * Created by wjbnys on 14-4-22.
 */
public class Contact {
    public long id = 0;
    public long raw_id = 0;
    public long photoid = 0;
    public String name = "";
    public String number = "";
    public Bitmap photo = null;
    public String source = "";
}
